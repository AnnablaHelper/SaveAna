""" Task 2 [6 points]"""

"""
Write a function 'PrPrCounter' which takes a list of numbers as an argument
and returns True if the number of all prime numbers is prime, 
False otherwise.

You can only use lambda functions and HOFS:
takewhile, dropwhile, zip, filter, map, reduce, enumerate,
any, all, sum.
You are not allowed to use for and while loops.
!WRITE IN ONE LINE!
"""

def prprCounter(lst):
    divisors = list(map(lambda a: a))
print(prprCounter([1,2,3,4,5,6,9]))
 